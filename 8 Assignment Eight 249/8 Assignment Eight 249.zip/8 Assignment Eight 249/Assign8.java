import java.util.ArrayList;
import java.util.Scanner;

public class Assign8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try{
			System.out.println("What level number would you like? ");
			String levelName = " ";
			Scanner keyboard = new Scanner(System.in);
			levelName = keyboard.next();
			
			//Open file "map" ...
			
			//Open file "monsters ....
			
			System.out.println("Number of monsters? ");
			int numMonsters = 0;
			numMonsters = keyboard.nextInt();
			
			ArrayList<Monster> monsterList = new ArrayList<>();
			
			System.out.println("Type of monster? ");
			
		}
	}

}
