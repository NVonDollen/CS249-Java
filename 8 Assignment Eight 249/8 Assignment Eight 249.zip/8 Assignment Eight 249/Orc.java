import java.util.Scanner;

public class Orc extends Monster{
	
	public Orc()
	{
		
	}
	
	public Orc(int newX, int newY, int newHealth)
	{
		super.setX(newX);
		super.setY(newY);
		super.setHealth(newHealth);
		
		
	}
	
	public interface Drawable
	{
		
	}
	
	public void load(Scanner input)
	{
		
	}
	
	public void drawToMap(Map map)
	{
	
	}
	
}
