
public interface Drawable {

	public abstract void drawToMap(Map screen);
}
