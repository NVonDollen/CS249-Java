
public class Human extends Unit {
	
	public Human()
	{
		super("Human",20,100);
	}
	
}
