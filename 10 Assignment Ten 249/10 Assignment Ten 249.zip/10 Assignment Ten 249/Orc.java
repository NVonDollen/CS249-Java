
public class Orc extends Unit {
	
	public Orc()
	{
		super("Orc",10,50);
	}
}
